﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManager_Modified
{
    class ParkingCar
    {
        //public int ParkingSpot { get; set; }
        public String ParkingSpot { get; set; }
        public string CarNumber { get; set; }
        public string DriverName { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime ParkingTime { get; set; }
    }
}
