﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crud
{
    class LogWriter
    {
        public static void PrintLog(string contetns)
        {
            //LogFolder라는 폴더가 생성되게 하는 거
            DirectoryInfo di = new DirectoryInfo("LogFolder");

            //di 경로에 해당하는 폴더가 있는지
            if (!di.Exists) 
            {
                //폴더 생성
                di.Create(); 
            }
            using (StreamWriter writer = 
                new StreamWriter("LogFolder\\Log.txt", true))
            {
                writer.WriteLine(contetns);
            }
        }
    }
}
