﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Crud
{
    public partial class Form1 : Form
    {
        string strconn = "Data Source=192.168.0.200;" +
            "Initial Catalog=2020DB;"
            + "Persist Security Info=True;" +
            "User ID=sa;Password=8765432!";

        public Form1()
        {
            InitializeComponent();
        }

        private void WriteLog(string contents)
        {
            string logContetns = $"[{DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")}] {contents}";
            LogWriter.PrintLog(logContetns);
        }

        private void selectQuery()
        {
            DataSet ds = new DataSet();

            SqlConnection sqlcon = new SqlConnection(strconn);
            sqlcon.Open();

            SqlDataAdapter adpt = new SqlDataAdapter("select * from MemberTable2", sqlcon);
            adpt.Fill(ds);

            dataGridView1.DataSource = ds.Tables[0];
            sqlcon.Close();

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //MessageBox.Show
                //    ($"선택한 값:{dataGridView1[e.ColumnIndex, e.RowIndex].Value}");
                WriteLog($"선택한 값:{dataGridView1[e.ColumnIndex, e.RowIndex].Value}");

                textBox_id.Text = dataGridView1[0, e.RowIndex].Value.ToString();
                textBox_name.Text = dataGridView1[1, e.RowIndex].Value.ToString();
                textBox_age.Text = dataGridView1[2, e.RowIndex].Value.ToString();
                textBox_bigo.Text = dataGridView1[4, e.RowIndex].Value.ToString();
            }
            catch (Exception except)
            {
                MessageBox.Show(except.Message);
                MessageBox.Show(except.StackTrace);
            }
        }

        private void button_select_Click(object sender, EventArgs e)
        {
            WriteLog("Select 버튼 클릭");
            //MessageBox.Show("Select 버튼 클릭");
            DataSet ds = new DataSet();

            SqlConnection sqlcon = new SqlConnection(strconn);
            sqlcon.Open();

            SqlDataAdapter adpt =
                new SqlDataAdapter("select * from MemberTable2", sqlcon);
            adpt.Fill(ds);

            dataGridView1.DataSource = ds.Tables[0];
            sqlcon.Close();
        }

        private void button_insert_Click(object sender, EventArgs e)
        {
            WriteLog("Insert 버튼 클릭");
            //MessageBox.Show("Insert 버튼 클릭");

            SqlConnection conn = new SqlConnection(strconn);
            conn.Open();
            SqlCommand cmd = new SqlCommand("insert into MemberTable2 " +
                                            "(ID, Name, age, rgdate, bigo) " +
                                            "values " +
                                            " (@ID, @name, @age, getdate(), @bigo)", conn);

            cmd.Parameters.AddWithValue("@ID", textBox_id.Text);
            cmd.Parameters.AddWithValue("@name", textBox_name.Text);
            cmd.Parameters.AddWithValue("@age", textBox_age.Text);
            cmd.Parameters.AddWithValue("@bigo", textBox_bigo.Text);

            cmd.ExecuteNonQuery();

            conn.Close();

            selectQuery();
            //강제 버튼 클릭
            //button_select.PerformClick();
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            WriteLog("update 버튼 클릭");
            //MessageBox.Show("update 버튼 클릭");

            SqlConnection conn = new SqlConnection(strconn);
            conn.Open();
            SqlCommand cmd = new SqlCommand("update MemberTable2 " +
                                            "set name = @name, age=@age, "+
                                            "bigo=@remark "+
                                            "where ID = @ID", conn);
            cmd.Parameters.AddWithValue("@ID", textBox_id.Text);
            cmd.Parameters.AddWithValue("@name", textBox_name.Text);
            cmd.Parameters.AddWithValue("@age", textBox_age.Text);
            cmd.Parameters.AddWithValue("@remark", textBox_bigo.Text);

            cmd.ExecuteNonQuery();

            conn.Close();
            
            selectQuery();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            WriteLog("delete 버튼 선택");
            //MessageBox.Show("delete 버튼 선택");
            SqlConnection conn = new SqlConnection(strconn);
            conn.Open();

            SqlCommand cmd = new SqlCommand
                ("delete from MemberTable2 where ID = @ididid", conn);
            cmd.Parameters.AddWithValue("@ididid", textBox_id.Text);
            cmd.ExecuteNonQuery();
            conn.Close();

            selectQuery();
        }
    }
}
