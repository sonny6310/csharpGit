﻿namespace Sunny.UI.Demo
{
    partial class FRadioButton
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiRadioButton12 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton13 = new Sunny.UI.UIRadioButton();
            this.uiLabel3 = new Sunny.UI.UILabel();
            this.uiRadioButton9 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton10 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton11 = new Sunny.UI.UIRadioButton();
            this.uiLabel2 = new Sunny.UI.UILabel();
            this.uiRadioButton5 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton7 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton8 = new Sunny.UI.UIRadioButton();
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.uiRadioButton6 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton3 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton4 = new Sunny.UI.UIRadioButton();
            this.uiLine3 = new Sunny.UI.UILine();
            this.uiRadioButton2 = new Sunny.UI.UIRadioButton();
            this.uiRadioButton1 = new Sunny.UI.UIRadioButton();
            this.uiLine2 = new Sunny.UI.UILine();
            this.uiRadioButtonGroup1 = new Sunny.UI.UIRadioButtonGroup();
            this.PagePanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // PagePanel
            // 
            this.PagePanel.Controls.Add(this.uiRadioButtonGroup1);
            this.PagePanel.Controls.Add(this.uiRadioButton12);
            this.PagePanel.Controls.Add(this.uiRadioButton13);
            this.PagePanel.Controls.Add(this.uiLabel3);
            this.PagePanel.Controls.Add(this.uiRadioButton9);
            this.PagePanel.Controls.Add(this.uiRadioButton10);
            this.PagePanel.Controls.Add(this.uiRadioButton11);
            this.PagePanel.Controls.Add(this.uiLabel2);
            this.PagePanel.Controls.Add(this.uiRadioButton5);
            this.PagePanel.Controls.Add(this.uiRadioButton7);
            this.PagePanel.Controls.Add(this.uiRadioButton8);
            this.PagePanel.Controls.Add(this.uiLabel1);
            this.PagePanel.Controls.Add(this.uiRadioButton6);
            this.PagePanel.Controls.Add(this.uiRadioButton3);
            this.PagePanel.Controls.Add(this.uiRadioButton4);
            this.PagePanel.Controls.Add(this.uiLine3);
            this.PagePanel.Controls.Add(this.uiRadioButton2);
            this.PagePanel.Controls.Add(this.uiRadioButton1);
            this.PagePanel.Controls.Add(this.uiLine2);
            this.PagePanel.Size = new System.Drawing.Size(800, 563);
            // 
            // uiRadioButton12
            // 
            this.uiRadioButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton12.Enabled = false;
            this.uiRadioButton12.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton12.GroupIndex = 4;
            this.uiRadioButton12.Location = new System.Drawing.Point(516, 48);
            this.uiRadioButton12.Name = "uiRadioButton12";
            this.uiRadioButton12.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton12.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton12.TabIndex = 61;
            this.uiRadioButton12.Text = "uiRadioButton12";
            // 
            // uiRadioButton13
            // 
            this.uiRadioButton13.Checked = true;
            this.uiRadioButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton13.Enabled = false;
            this.uiRadioButton13.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton13.GroupIndex = 4;
            this.uiRadioButton13.Location = new System.Drawing.Point(354, 48);
            this.uiRadioButton13.Name = "uiRadioButton13";
            this.uiRadioButton13.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton13.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton13.TabIndex = 60;
            this.uiRadioButton13.Text = "uiRadioButton13";
            // 
            // uiLabel3
            // 
            this.uiLabel3.AutoSize = true;
            this.uiLabel3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel3.Location = new System.Drawing.Point(49, 219);
            this.uiLabel3.Name = "uiLabel3";
            this.uiLabel3.Size = new System.Drawing.Size(131, 21);
            this.uiLabel3.TabIndex = 59;
            this.uiLabel3.Text = "GroupIndex = 3";
            this.uiLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiRadioButton9
            // 
            this.uiRadioButton9.Checked = true;
            this.uiRadioButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton9.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton9.GroupIndex = 3;
            this.uiRadioButton9.Location = new System.Drawing.Point(516, 212);
            this.uiRadioButton9.Name = "uiRadioButton9";
            this.uiRadioButton9.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton9.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton9.TabIndex = 58;
            this.uiRadioButton9.Text = "uiRadioButton33";
            // 
            // uiRadioButton10
            // 
            this.uiRadioButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton10.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton10.GroupIndex = 3;
            this.uiRadioButton10.Location = new System.Drawing.Point(354, 212);
            this.uiRadioButton10.Name = "uiRadioButton10";
            this.uiRadioButton10.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton10.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton10.TabIndex = 57;
            this.uiRadioButton10.Text = "uiRadioButton32";
            // 
            // uiRadioButton11
            // 
            this.uiRadioButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton11.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton11.GroupIndex = 3;
            this.uiRadioButton11.Location = new System.Drawing.Point(192, 212);
            this.uiRadioButton11.Name = "uiRadioButton11";
            this.uiRadioButton11.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton11.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton11.TabIndex = 56;
            this.uiRadioButton11.Text = "uiRadioButton31";
            // 
            // uiLabel2
            // 
            this.uiLabel2.AutoSize = true;
            this.uiLabel2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel2.Location = new System.Drawing.Point(49, 178);
            this.uiLabel2.Name = "uiLabel2";
            this.uiLabel2.Size = new System.Drawing.Size(131, 21);
            this.uiLabel2.TabIndex = 55;
            this.uiLabel2.Text = "GroupIndex = 2";
            this.uiLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiRadioButton5
            // 
            this.uiRadioButton5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton5.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton5.GroupIndex = 2;
            this.uiRadioButton5.Location = new System.Drawing.Point(516, 171);
            this.uiRadioButton5.Name = "uiRadioButton5";
            this.uiRadioButton5.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton5.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton5.TabIndex = 54;
            this.uiRadioButton5.Text = "uiRadioButton23";
            // 
            // uiRadioButton7
            // 
            this.uiRadioButton7.Checked = true;
            this.uiRadioButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton7.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton7.GroupIndex = 2;
            this.uiRadioButton7.Location = new System.Drawing.Point(354, 171);
            this.uiRadioButton7.Name = "uiRadioButton7";
            this.uiRadioButton7.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton7.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton7.TabIndex = 53;
            this.uiRadioButton7.Text = "uiRadioButton22";
            // 
            // uiRadioButton8
            // 
            this.uiRadioButton8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton8.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton8.GroupIndex = 2;
            this.uiRadioButton8.Location = new System.Drawing.Point(192, 171);
            this.uiRadioButton8.Name = "uiRadioButton8";
            this.uiRadioButton8.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton8.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton8.TabIndex = 52;
            this.uiRadioButton8.Text = "uiRadioButton21";
            // 
            // uiLabel1
            // 
            this.uiLabel1.AutoSize = true;
            this.uiLabel1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel1.Location = new System.Drawing.Point(49, 137);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(131, 21);
            this.uiLabel1.TabIndex = 51;
            this.uiLabel1.Text = "GroupIndex = 1";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiRadioButton6
            // 
            this.uiRadioButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton6.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton6.GroupIndex = 1;
            this.uiRadioButton6.Location = new System.Drawing.Point(516, 130);
            this.uiRadioButton6.Name = "uiRadioButton6";
            this.uiRadioButton6.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton6.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton6.TabIndex = 50;
            this.uiRadioButton6.Text = "uiRadioButton13";
            // 
            // uiRadioButton3
            // 
            this.uiRadioButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton3.GroupIndex = 1;
            this.uiRadioButton3.Location = new System.Drawing.Point(354, 130);
            this.uiRadioButton3.Name = "uiRadioButton3";
            this.uiRadioButton3.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton3.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton3.TabIndex = 49;
            this.uiRadioButton3.Text = "uiRadioButton12";
            // 
            // uiRadioButton4
            // 
            this.uiRadioButton4.Checked = true;
            this.uiRadioButton4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton4.GroupIndex = 1;
            this.uiRadioButton4.Location = new System.Drawing.Point(192, 130);
            this.uiRadioButton4.Name = "uiRadioButton4";
            this.uiRadioButton4.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton4.Size = new System.Drawing.Size(156, 35);
            this.uiRadioButton4.TabIndex = 48;
            this.uiRadioButton4.Text = "uiRadioButton11";
            // 
            // uiLine3
            // 
            this.uiLine3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine3.Location = new System.Drawing.Point(30, 96);
            this.uiLine3.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine3.Name = "uiLine3";
            this.uiLine3.Size = new System.Drawing.Size(670, 20);
            this.uiLine3.TabIndex = 47;
            this.uiLine3.Text = "UIRadioButton 分组";
            this.uiLine3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiRadioButton2
            // 
            this.uiRadioButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton2.Location = new System.Drawing.Point(192, 48);
            this.uiRadioButton2.Name = "uiRadioButton2";
            this.uiRadioButton2.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton2.Size = new System.Drawing.Size(150, 35);
            this.uiRadioButton2.TabIndex = 46;
            this.uiRadioButton2.Text = "uiRadioButton2";
            // 
            // uiRadioButton1
            // 
            this.uiRadioButton1.Checked = true;
            this.uiRadioButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.uiRadioButton1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButton1.Location = new System.Drawing.Point(30, 48);
            this.uiRadioButton1.Name = "uiRadioButton1";
            this.uiRadioButton1.Padding = new System.Windows.Forms.Padding(22, 0, 0, 0);
            this.uiRadioButton1.Size = new System.Drawing.Size(150, 35);
            this.uiRadioButton1.TabIndex = 45;
            this.uiRadioButton1.Text = "uiRadioButton1";
            // 
            // uiLine2
            // 
            this.uiLine2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine2.Location = new System.Drawing.Point(30, 20);
            this.uiLine2.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine2.Name = "uiLine2";
            this.uiLine2.Size = new System.Drawing.Size(670, 20);
            this.uiLine2.TabIndex = 44;
            this.uiLine2.Text = "UIRadioButton";
            this.uiLine2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiRadioButtonGroup1
            // 
            this.uiRadioButtonGroup1.ColumnCount = 3;
            this.uiRadioButtonGroup1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiRadioButtonGroup1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.uiRadioButtonGroup1.Location = new System.Drawing.Point(30, 253);
            this.uiRadioButtonGroup1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiRadioButtonGroup1.Name = "uiRadioButtonGroup1";
            this.uiRadioButtonGroup1.Padding = new System.Windows.Forms.Padding(0, 32, 0, 0);
            this.uiRadioButtonGroup1.Size = new System.Drawing.Size(670, 173);
            this.uiRadioButtonGroup1.TabIndex = 63;
            this.uiRadioButtonGroup1.Text = "UIRadioButtonGroup";
            this.uiRadioButtonGroup1.ValueChanged += new Sunny.UI.UIRadioButtonGroup.OnValueChanged(this.uiRadioButtonGroup1_ValueChanged);
            // 
            // FRadioButton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 598);
            this.Name = "FRadioButton";
            this.Symbol = 61842;
            this.Text = "RadioButton";
            this.PagePanel.ResumeLayout(false);
            this.PagePanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private UIRadioButton uiRadioButton12;
        private UIRadioButton uiRadioButton13;
        private UILabel uiLabel3;
        private UIRadioButton uiRadioButton9;
        private UIRadioButton uiRadioButton10;
        private UIRadioButton uiRadioButton11;
        private UILabel uiLabel2;
        private UIRadioButton uiRadioButton5;
        private UIRadioButton uiRadioButton7;
        private UIRadioButton uiRadioButton8;
        private UILabel uiLabel1;
        private UIRadioButton uiRadioButton6;
        private UIRadioButton uiRadioButton3;
        private UIRadioButton uiRadioButton4;
        private UILine uiLine3;
        private UIRadioButton uiRadioButton2;
        private UIRadioButton uiRadioButton1;
        private UILine uiLine2;
        private UIRadioButtonGroup uiRadioButtonGroup1;
    }
}