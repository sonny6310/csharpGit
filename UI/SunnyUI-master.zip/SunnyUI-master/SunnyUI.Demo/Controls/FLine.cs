﻿namespace Sunny.UI.Demo
{
    public partial class FLine : UITitlePage
    {
        public FLine()
        {
            InitializeComponent();
        }
    }
}