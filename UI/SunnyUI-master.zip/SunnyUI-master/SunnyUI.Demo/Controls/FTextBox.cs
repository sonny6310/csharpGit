﻿namespace Sunny.UI.Demo
{
    public partial class FTextBox : UITitlePage
    {
        public FTextBox()
        {
            InitializeComponent();
        }
    }
}