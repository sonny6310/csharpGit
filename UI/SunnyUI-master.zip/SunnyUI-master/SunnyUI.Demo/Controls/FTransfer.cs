﻿namespace Sunny.UI.Demo
{
    public partial class FTransfer : UITitlePage
    {
        public FTransfer()
        {
            InitializeComponent();
        }
    }
}
