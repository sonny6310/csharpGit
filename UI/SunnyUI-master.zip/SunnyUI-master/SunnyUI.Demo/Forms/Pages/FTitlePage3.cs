﻿namespace Sunny.UI.Demo
{
    public partial class FTitlePage3 : UITitlePage
    {
        public FTitlePage3()
        {
            InitializeComponent();
        }
    }
}