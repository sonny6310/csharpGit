﻿namespace Sunny.UI.Demo
{
    public partial class FPage2 : UIPage
    {
        public FPage2()
        {
            InitializeComponent();
        }
    }
}