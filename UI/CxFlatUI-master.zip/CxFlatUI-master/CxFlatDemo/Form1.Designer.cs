﻿using CxFlatUI;
using CxFlatUI.Controls;

namespace CxFlatDemo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.cxFlatStatusBar1 = new CxFlatUI.CxFlatStatusBar();
            this.cxFlatTabControl1 = new CxFlatUI.CxFlatTabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.cxFlatTextBox2 = new CxFlatUI.CxFlatTextBox();
            this.cxFlatContextMenuStrip1 = new CxFlatUI.CxFlatContextMenuStrip();
            this.abcdefToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sdssToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sdhlkjdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.sadsdbToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.下拉菜单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.asdfgToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.cxFlatButton2 = new CxFlatUI.Controls.CxFlatButton();
            this.cxFlatTextBox1 = new CxFlatUI.CxFlatTextBox();
            this.cxFlatPictureBox1 = new CxFlatUI.CxFlatPictureBox();
            this.cxFlatNumericUpDown2 = new CxFlatUI.CxFlatNumericUpDown();
            this.cxFlatNumericUpDown1 = new CxFlatUI.CxFlatNumericUpDown();
            this.cxFlatSliderBar1 = new CxFlatUI.CxFlatSliderBar();
            this.cxFlatPictureBox2 = new CxFlatUI.CxFlatPictureBox();
            this.cxFlatGroupBox2 = new CxFlatUI.CxFlatGroupBox();
            this.cxFlatSwitch2 = new CxFlatUI.CxFlatSwitch();
            this.cxFlatToggle1 = new CxFlatUI.CxFlatToggle();
            this.cxFlatCheckBox2 = new CxFlatUI.CxFlatCheckBox();
            this.cxFlatCheckBox1 = new CxFlatUI.CxFlatCheckBox();
            this.cxFlatSwitch1 = new CxFlatUI.CxFlatSwitch();
            this.cxFlatToggle2 = new CxFlatUI.CxFlatToggle();
            this.cxFlatAlertBox4 = new CxFlatUI.CxFlatAlertBox();
            this.cxFlatAlertBox3 = new CxFlatUI.CxFlatAlertBox();
            this.cxFlatAlertBox2 = new CxFlatUI.CxFlatAlertBox();
            this.cxFlatAlertBox1 = new CxFlatUI.CxFlatAlertBox();
            this.cxFlatGroupBox1 = new CxFlatUI.CxFlatGroupBox();
            this.cxFlatRadioButton3 = new CxFlatUI.CxFlatRadioButton();
            this.cxFlatRadioButton2 = new CxFlatUI.CxFlatRadioButton();
            this.cxFlatRadioButton1 = new CxFlatUI.CxFlatRadioButton();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cxFlatRoundProgressBar4 = new CxFlatUI.CxFlatRoundProgressBar();
            this.cxFlatProgressBar12 = new CxFlatUI.CxFlatProgressBar();
            this.cxFlatProgressBar11 = new CxFlatUI.CxFlatProgressBar();
            this.cxFlatProgressBar10 = new CxFlatUI.CxFlatProgressBar();
            this.cxFlatProgressBar9 = new CxFlatUI.CxFlatProgressBar();
            this.cxFlatProgressBar8 = new CxFlatUI.CxFlatProgressBar();
            this.cxFlatProgressBar7 = new CxFlatUI.CxFlatProgressBar();
            this.cxFlatProgressBar6 = new CxFlatUI.CxFlatProgressBar();
            this.cxFlatProgressBar5 = new CxFlatUI.CxFlatProgressBar();
            this.cxFlatProgressBar4 = new CxFlatUI.CxFlatProgressBar();
            this.cxFlatProgressBar3 = new CxFlatUI.CxFlatProgressBar();
            this.cxFlatProgressBar2 = new CxFlatUI.CxFlatProgressBar();
            this.cxFlatRoundProgressBar3 = new CxFlatUI.CxFlatRoundProgressBar();
            this.cxFlatRoundProgressBar2 = new CxFlatUI.CxFlatRoundProgressBar();
            this.cxFlatSimpleButton6 = new CxFlatUI.CxFlatSimpleButton();
            this.cxFlatSimpleButton5 = new CxFlatUI.CxFlatSimpleButton();
            this.cxFlatSimpleButton4 = new CxFlatUI.CxFlatSimpleButton();
            this.cxFlatSimpleButton3 = new CxFlatUI.CxFlatSimpleButton();
            this.cxFlatSimpleButton2 = new CxFlatUI.CxFlatSimpleButton();
            this.cxFlatSimpleButton1 = new CxFlatUI.CxFlatSimpleButton();
            this.cxFlatRoundButton7 = new CxFlatUI.CxFlatRoundButton();
            this.cxFlatRoundButton6 = new CxFlatUI.CxFlatRoundButton();
            this.cxFlatRoundButton5 = new CxFlatUI.CxFlatRoundButton();
            this.cxFlatRoundButton4 = new CxFlatUI.CxFlatRoundButton();
            this.cxFlatRoundButton3 = new CxFlatUI.CxFlatRoundButton();
            this.cxFlatRoundButton2 = new CxFlatUI.CxFlatRoundButton();
            this.cxFlatButton9 = new CxFlatUI.Controls.CxFlatButton();
            this.cxFlatButton8 = new CxFlatUI.Controls.CxFlatButton();
            this.cxFlatButton7 = new CxFlatUI.Controls.CxFlatButton();
            this.cxFlatButton6 = new CxFlatUI.Controls.CxFlatButton();
            this.cxFlatButton5 = new CxFlatUI.Controls.CxFlatButton();
            this.cxFlatButton4 = new CxFlatUI.Controls.CxFlatButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cxFlatDatePicker1 = new CxFlatUI.Controls.CxFlatDatePicker();
            this.cxFlatButton1 = new CxFlatUI.Controls.CxFlatButton();
            this.cxFlatComboBox1 = new CxFlatUI.CxFlatComboBox();
            this.cxFlatTabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.cxFlatContextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cxFlatPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cxFlatPictureBox2)).BeginInit();
            this.cxFlatGroupBox2.SuspendLayout();
            this.cxFlatGroupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // cxFlatStatusBar1
            // 
            this.cxFlatStatusBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cxFlatStatusBar1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatStatusBar1.Location = new System.Drawing.Point(0, 0);
            this.cxFlatStatusBar1.Name = "cxFlatStatusBar1";
            this.cxFlatStatusBar1.Size = new System.Drawing.Size(825, 40);
            this.cxFlatStatusBar1.TabIndex = 12;
            this.cxFlatStatusBar1.Text = "cxFlatStatusBar1";
            this.cxFlatStatusBar1.ThemeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(158)))), ((int)(((byte)(255)))));
            // 
            // cxFlatTabControl1
            // 
            this.cxFlatTabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cxFlatTabControl1.Controls.Add(this.tabPage1);
            this.cxFlatTabControl1.Controls.Add(this.tabPage2);
            this.cxFlatTabControl1.Controls.Add(this.tabPage3);
            this.cxFlatTabControl1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatTabControl1.HotTrack = true;
            this.cxFlatTabControl1.ItemSize = new System.Drawing.Size(120, 40);
            this.cxFlatTabControl1.Location = new System.Drawing.Point(0, 51);
            this.cxFlatTabControl1.Name = "cxFlatTabControl1";
            this.cxFlatTabControl1.SelectedIndex = 0;
            this.cxFlatTabControl1.Size = new System.Drawing.Size(825, 492);
            this.cxFlatTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.cxFlatTabControl1.TabIndex = 11;
            this.cxFlatTabControl1.ThemeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(158)))), ((int)(((byte)(255)))));
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.White;
            this.tabPage1.Controls.Add(this.cxFlatComboBox1);
            this.tabPage1.Controls.Add(this.cxFlatTextBox2);
            this.tabPage1.Controls.Add(this.cxFlatButton2);
            this.tabPage1.Controls.Add(this.cxFlatTextBox1);
            this.tabPage1.Controls.Add(this.cxFlatPictureBox1);
            this.tabPage1.Controls.Add(this.cxFlatNumericUpDown2);
            this.tabPage1.Controls.Add(this.cxFlatNumericUpDown1);
            this.tabPage1.Controls.Add(this.cxFlatSliderBar1);
            this.tabPage1.Controls.Add(this.cxFlatPictureBox2);
            this.tabPage1.Controls.Add(this.cxFlatGroupBox2);
            this.tabPage1.Controls.Add(this.cxFlatAlertBox4);
            this.tabPage1.Controls.Add(this.cxFlatAlertBox3);
            this.tabPage1.Controls.Add(this.cxFlatAlertBox2);
            this.tabPage1.Controls.Add(this.cxFlatAlertBox1);
            this.tabPage1.Controls.Add(this.cxFlatGroupBox1);
            this.tabPage1.Location = new System.Drawing.Point(0, 40);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(825, 452);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            // 
            // cxFlatTextBox2
            // 
            this.cxFlatTextBox2.ContextMenuStrip = this.cxFlatContextMenuStrip1;
            this.cxFlatTextBox2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cxFlatTextBox2.Hint = "请输入内容";
            this.cxFlatTextBox2.Location = new System.Drawing.Point(576, 271);
            this.cxFlatTextBox2.MaxLength = 32767;
            this.cxFlatTextBox2.Multiline = true;
            this.cxFlatTextBox2.Name = "cxFlatTextBox2";
            this.cxFlatTextBox2.PasswordChar = '\0';
            this.cxFlatTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.cxFlatTextBox2.SelectedText = "";
            this.cxFlatTextBox2.SelectionLength = 0;
            this.cxFlatTextBox2.SelectionStart = 0;
            this.cxFlatTextBox2.Size = new System.Drawing.Size(226, 144);
            this.cxFlatTextBox2.TabIndex = 28;
            this.cxFlatTextBox2.TabStop = false;
            this.cxFlatTextBox2.UseSystemPasswordChar = false;
            // 
            // cxFlatContextMenuStrip1
            // 
            this.cxFlatContextMenuStrip1.BackColor = System.Drawing.Color.White;
            this.cxFlatContextMenuStrip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(49)))), ((int)(((byte)(51)))));
            this.cxFlatContextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.abcdefToolStripMenuItem,
            this.sdssToolStripMenuItem,
            this.sdhlkjdToolStripMenuItem,
            this.toolStripSeparator1,
            this.sadsdbToolStripMenuItem,
            this.下拉菜单ToolStripMenuItem});
            this.cxFlatContextMenuStrip1.Name = "cxFlatContextMenuStrip1";
            this.cxFlatContextMenuStrip1.Size = new System.Drawing.Size(125, 120);
            this.cxFlatContextMenuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.cxFlatContextMenuStrip1_ItemClicked);
            // 
            // abcdefToolStripMenuItem
            // 
            this.abcdefToolStripMenuItem.Name = "abcdefToolStripMenuItem";
            this.abcdefToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.abcdefToolStripMenuItem.Text = "abcdef";
            // 
            // sdssToolStripMenuItem
            // 
            this.sdssToolStripMenuItem.Name = "sdssToolStripMenuItem";
            this.sdssToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.sdssToolStripMenuItem.Text = "123sdss";
            // 
            // sdhlkjdToolStripMenuItem
            // 
            this.sdhlkjdToolStripMenuItem.Name = "sdhlkjdToolStripMenuItem";
            this.sdhlkjdToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.sdhlkjdToolStripMenuItem.Text = "sdhlkjd";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(121, 6);
            // 
            // sadsdbToolStripMenuItem
            // 
            this.sadsdbToolStripMenuItem.Name = "sadsdbToolStripMenuItem";
            this.sadsdbToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.sadsdbToolStripMenuItem.Text = "sadsdb";
            // 
            // 下拉菜单ToolStripMenuItem
            // 
            this.下拉菜单ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.asdfgToolStripMenuItem,
            this.toolStripMenuItem2});
            this.下拉菜单ToolStripMenuItem.Name = "下拉菜单ToolStripMenuItem";
            this.下拉菜单ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.下拉菜单ToolStripMenuItem.Text = "下拉菜单";
            // 
            // asdfgToolStripMenuItem
            // 
            this.asdfgToolStripMenuItem.Name = "asdfgToolStripMenuItem";
            this.asdfgToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.asdfgToolStripMenuItem.Text = "asdfg";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(132, 22);
            this.toolStripMenuItem2.Text = "12345678";
            // 
            // cxFlatButton2
            // 
            this.cxFlatButton2.ButtonType = CxFlatUI.ButtonType.Primary;
            this.cxFlatButton2.ContextMenuStrip = this.cxFlatContextMenuStrip1;
            this.cxFlatButton2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatButton2.Location = new System.Drawing.Point(322, 315);
            this.cxFlatButton2.Name = "cxFlatButton2";
            this.cxFlatButton2.Size = new System.Drawing.Size(222, 40);
            this.cxFlatButton2.TabIndex = 27;
            this.cxFlatButton2.Text = "cxFlatButton2";
            this.cxFlatButton2.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatTextBox1
            // 
            this.cxFlatTextBox1.ContextMenuStrip = this.cxFlatContextMenuStrip1;
            this.cxFlatTextBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cxFlatTextBox1.Hint = "请输入内容";
            this.cxFlatTextBox1.Location = new System.Drawing.Point(322, 271);
            this.cxFlatTextBox1.MaxLength = 32767;
            this.cxFlatTextBox1.Multiline = false;
            this.cxFlatTextBox1.Name = "cxFlatTextBox1";
            this.cxFlatTextBox1.PasswordChar = '\0';
            this.cxFlatTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.cxFlatTextBox1.SelectedText = "";
            this.cxFlatTextBox1.SelectionLength = 0;
            this.cxFlatTextBox1.SelectionStart = 0;
            this.cxFlatTextBox1.Size = new System.Drawing.Size(222, 38);
            this.cxFlatTextBox1.TabIndex = 26;
            this.cxFlatTextBox1.TabStop = false;
            this.cxFlatTextBox1.UseSystemPasswordChar = false;
            // 
            // cxFlatPictureBox1
            // 
            this.cxFlatPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("cxFlatPictureBox1.Image")));
            this.cxFlatPictureBox1.Location = new System.Drawing.Point(168, 271);
            this.cxFlatPictureBox1.Name = "cxFlatPictureBox1";
            this.cxFlatPictureBox1.Size = new System.Drawing.Size(139, 94);
            this.cxFlatPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cxFlatPictureBox1.TabIndex = 20;
            this.cxFlatPictureBox1.TabStop = false;
            // 
            // cxFlatNumericUpDown2
            // 
            this.cxFlatNumericUpDown2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatNumericUpDown2.Location = new System.Drawing.Point(168, 383);
            this.cxFlatNumericUpDown2.MaxNum = 10F;
            this.cxFlatNumericUpDown2.MinNum = 0F;
            this.cxFlatNumericUpDown2.Name = "cxFlatNumericUpDown2";
            this.cxFlatNumericUpDown2.Precision = 0;
            this.cxFlatNumericUpDown2.Size = new System.Drawing.Size(139, 32);
            this.cxFlatNumericUpDown2.Step = 1F;
            this.cxFlatNumericUpDown2.Style = CxFlatUI.CxFlatNumericUpDown.NumericStyle.TopDown;
            this.cxFlatNumericUpDown2.TabIndex = 25;
            this.cxFlatNumericUpDown2.Text = "cxFlatNumericUpDown2";
            this.cxFlatNumericUpDown2.ValueNumber = 0F;
            // 
            // cxFlatNumericUpDown1
            // 
            this.cxFlatNumericUpDown1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatNumericUpDown1.Location = new System.Drawing.Point(22, 383);
            this.cxFlatNumericUpDown1.MaxNum = 10F;
            this.cxFlatNumericUpDown1.MinNum = 0F;
            this.cxFlatNumericUpDown1.Name = "cxFlatNumericUpDown1";
            this.cxFlatNumericUpDown1.Precision = 2;
            this.cxFlatNumericUpDown1.Size = new System.Drawing.Size(139, 32);
            this.cxFlatNumericUpDown1.Step = 0.1F;
            this.cxFlatNumericUpDown1.Style = CxFlatUI.CxFlatNumericUpDown.NumericStyle.LeftRight;
            this.cxFlatNumericUpDown1.TabIndex = 24;
            this.cxFlatNumericUpDown1.Text = "cxFlatNumericUpDown1";
            this.cxFlatNumericUpDown1.ValueNumber = 0F;
            // 
            // cxFlatSliderBar1
            // 
            this.cxFlatSliderBar1.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.cxFlatSliderBar1.Location = new System.Drawing.Point(22, 207);
            this.cxFlatSliderBar1.MaxValue = 10;
            this.cxFlatSliderBar1.MinValue = 0;
            this.cxFlatSliderBar1.Name = "cxFlatSliderBar1";
            this.cxFlatSliderBar1.ShowValue = true;
            this.cxFlatSliderBar1.Size = new System.Drawing.Size(780, 45);
            this.cxFlatSliderBar1.TabIndex = 22;
            this.cxFlatSliderBar1.Text = "cxFlatSliderBar1";
            this.cxFlatSliderBar1.ThemeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(158)))), ((int)(((byte)(255)))));
            this.cxFlatSliderBar1.Value = 0;
            // 
            // cxFlatPictureBox2
            // 
            this.cxFlatPictureBox2.Location = new System.Drawing.Point(22, 271);
            this.cxFlatPictureBox2.Name = "cxFlatPictureBox2";
            this.cxFlatPictureBox2.Size = new System.Drawing.Size(139, 94);
            this.cxFlatPictureBox2.TabIndex = 21;
            this.cxFlatPictureBox2.TabStop = false;
            // 
            // cxFlatGroupBox2
            // 
            this.cxFlatGroupBox2.BackColor = System.Drawing.Color.White;
            this.cxFlatGroupBox2.Controls.Add(this.cxFlatSwitch2);
            this.cxFlatGroupBox2.Controls.Add(this.cxFlatToggle1);
            this.cxFlatGroupBox2.Controls.Add(this.cxFlatCheckBox2);
            this.cxFlatGroupBox2.Controls.Add(this.cxFlatCheckBox1);
            this.cxFlatGroupBox2.Controls.Add(this.cxFlatSwitch1);
            this.cxFlatGroupBox2.Controls.Add(this.cxFlatToggle2);
            this.cxFlatGroupBox2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatGroupBox2.Location = new System.Drawing.Point(576, 17);
            this.cxFlatGroupBox2.Name = "cxFlatGroupBox2";
            this.cxFlatGroupBox2.ShowText = false;
            this.cxFlatGroupBox2.Size = new System.Drawing.Size(226, 184);
            this.cxFlatGroupBox2.TabIndex = 18;
            this.cxFlatGroupBox2.TabStop = false;
            this.cxFlatGroupBox2.Text = "cxFlatGroupBox2";
            this.cxFlatGroupBox2.ThemeColor = System.Drawing.Color.Blue;
            // 
            // cxFlatSwitch2
            // 
            this.cxFlatSwitch2.AutoSize = true;
            this.cxFlatSwitch2.Location = new System.Drawing.Point(35, 111);
            this.cxFlatSwitch2.Name = "cxFlatSwitch2";
            this.cxFlatSwitch2.Size = new System.Drawing.Size(40, 20);
            this.cxFlatSwitch2.TabIndex = 4;
            this.cxFlatSwitch2.Text = "cxFlatSwitch2";
            this.cxFlatSwitch2.UseVisualStyleBackColor = true;
            // 
            // cxFlatToggle1
            // 
            this.cxFlatToggle1.AutoSize = true;
            this.cxFlatToggle1.Checked = true;
            this.cxFlatToggle1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cxFlatToggle1.Location = new System.Drawing.Point(110, 149);
            this.cxFlatToggle1.Name = "cxFlatToggle1";
            this.cxFlatToggle1.Size = new System.Drawing.Size(48, 20);
            this.cxFlatToggle1.TabIndex = 10;
            this.cxFlatToggle1.Text = "cxFlatToggle1";
            this.cxFlatToggle1.UseVisualStyleBackColor = true;
            // 
            // cxFlatCheckBox2
            // 
            this.cxFlatCheckBox2.AutoSize = true;
            this.cxFlatCheckBox2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatCheckBox2.Location = new System.Drawing.Point(35, 65);
            this.cxFlatCheckBox2.Name = "cxFlatCheckBox2";
            this.cxFlatCheckBox2.Size = new System.Drawing.Size(151, 20);
            this.cxFlatCheckBox2.TabIndex = 3;
            this.cxFlatCheckBox2.Text = "cxFlatCheckBox2";
            this.cxFlatCheckBox2.UseVisualStyleBackColor = true;
            // 
            // cxFlatCheckBox1
            // 
            this.cxFlatCheckBox1.AutoSize = true;
            this.cxFlatCheckBox1.BackColor = System.Drawing.Color.White;
            this.cxFlatCheckBox1.Checked = true;
            this.cxFlatCheckBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cxFlatCheckBox1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatCheckBox1.Location = new System.Drawing.Point(35, 28);
            this.cxFlatCheckBox1.Name = "cxFlatCheckBox1";
            this.cxFlatCheckBox1.Size = new System.Drawing.Size(151, 20);
            this.cxFlatCheckBox1.TabIndex = 2;
            this.cxFlatCheckBox1.Text = "cxFlatCheckBox1";
            this.cxFlatCheckBox1.UseVisualStyleBackColor = false;
            // 
            // cxFlatSwitch1
            // 
            this.cxFlatSwitch1.AutoSize = true;
            this.cxFlatSwitch1.Checked = true;
            this.cxFlatSwitch1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cxFlatSwitch1.Location = new System.Drawing.Point(35, 149);
            this.cxFlatSwitch1.Name = "cxFlatSwitch1";
            this.cxFlatSwitch1.Size = new System.Drawing.Size(40, 20);
            this.cxFlatSwitch1.TabIndex = 17;
            this.cxFlatSwitch1.Text = "cxFlatSwitch1";
            this.cxFlatSwitch1.UseVisualStyleBackColor = true;
            // 
            // cxFlatToggle2
            // 
            this.cxFlatToggle2.AutoSize = true;
            this.cxFlatToggle2.Location = new System.Drawing.Point(110, 111);
            this.cxFlatToggle2.Name = "cxFlatToggle2";
            this.cxFlatToggle2.Size = new System.Drawing.Size(48, 20);
            this.cxFlatToggle2.TabIndex = 10;
            this.cxFlatToggle2.Text = "cxFlatToggle2";
            this.cxFlatToggle2.UseVisualStyleBackColor = true;
            this.cxFlatToggle2.CheckStateChanged += new System.EventHandler(this.button1_Click);
            // 
            // cxFlatAlertBox4
            // 
            this.cxFlatAlertBox4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.cxFlatAlertBox4.Location = new System.Drawing.Point(22, 137);
            this.cxFlatAlertBox4.Name = "cxFlatAlertBox4";
            this.cxFlatAlertBox4.Size = new System.Drawing.Size(285, 34);
            this.cxFlatAlertBox4.TabIndex = 16;
            this.cxFlatAlertBox4.Text = "cxFlatAlertBox4";
            this.cxFlatAlertBox4.Type = CxFlatUI.CxFlatAlertBox.AlertType.Success;
            // 
            // cxFlatAlertBox3
            // 
            this.cxFlatAlertBox3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.cxFlatAlertBox3.Location = new System.Drawing.Point(22, 97);
            this.cxFlatAlertBox3.Name = "cxFlatAlertBox3";
            this.cxFlatAlertBox3.Size = new System.Drawing.Size(285, 34);
            this.cxFlatAlertBox3.TabIndex = 15;
            this.cxFlatAlertBox3.Text = "cxFlatAlertBox3";
            this.cxFlatAlertBox3.Type = CxFlatUI.CxFlatAlertBox.AlertType.info;
            // 
            // cxFlatAlertBox2
            // 
            this.cxFlatAlertBox2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.cxFlatAlertBox2.Location = new System.Drawing.Point(22, 57);
            this.cxFlatAlertBox2.Name = "cxFlatAlertBox2";
            this.cxFlatAlertBox2.Size = new System.Drawing.Size(285, 34);
            this.cxFlatAlertBox2.TabIndex = 14;
            this.cxFlatAlertBox2.Text = "cxFlatAlertBox2";
            this.cxFlatAlertBox2.Type = CxFlatUI.CxFlatAlertBox.AlertType.Warning;
            // 
            // cxFlatAlertBox1
            // 
            this.cxFlatAlertBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cxFlatAlertBox1.Location = new System.Drawing.Point(22, 17);
            this.cxFlatAlertBox1.Name = "cxFlatAlertBox1";
            this.cxFlatAlertBox1.Size = new System.Drawing.Size(285, 34);
            this.cxFlatAlertBox1.TabIndex = 13;
            this.cxFlatAlertBox1.Text = "cxFlatAlertBox1";
            this.cxFlatAlertBox1.Type = CxFlatUI.CxFlatAlertBox.AlertType.Error;
            // 
            // cxFlatGroupBox1
            // 
            this.cxFlatGroupBox1.BackColor = System.Drawing.Color.White;
            this.cxFlatGroupBox1.Controls.Add(this.cxFlatRadioButton3);
            this.cxFlatGroupBox1.Controls.Add(this.cxFlatRadioButton2);
            this.cxFlatGroupBox1.Controls.Add(this.cxFlatRadioButton1);
            this.cxFlatGroupBox1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatGroupBox1.Location = new System.Drawing.Point(322, 17);
            this.cxFlatGroupBox1.Name = "cxFlatGroupBox1";
            this.cxFlatGroupBox1.ShowText = true;
            this.cxFlatGroupBox1.Size = new System.Drawing.Size(243, 184);
            this.cxFlatGroupBox1.TabIndex = 8;
            this.cxFlatGroupBox1.TabStop = false;
            this.cxFlatGroupBox1.Text = "cxFlatGroupBox1";
            this.cxFlatGroupBox1.ThemeColor = System.Drawing.Color.RoyalBlue;
            // 
            // cxFlatRadioButton3
            // 
            this.cxFlatRadioButton3.AutoSize = true;
            this.cxFlatRadioButton3.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(158)))), ((int)(((byte)(255)))));
            this.cxFlatRadioButton3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatRadioButton3.Location = new System.Drawing.Point(36, 126);
            this.cxFlatRadioButton3.Name = "cxFlatRadioButton3";
            this.cxFlatRadioButton3.Size = new System.Drawing.Size(170, 20);
            this.cxFlatRadioButton3.TabIndex = 2;
            this.cxFlatRadioButton3.TabStop = true;
            this.cxFlatRadioButton3.Text = "cxFlatRadioButton3";
            this.cxFlatRadioButton3.UseVisualStyleBackColor = true;
            // 
            // cxFlatRadioButton2
            // 
            this.cxFlatRadioButton2.AutoSize = true;
            this.cxFlatRadioButton2.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(158)))), ((int)(((byte)(255)))));
            this.cxFlatRadioButton2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatRadioButton2.Location = new System.Drawing.Point(36, 93);
            this.cxFlatRadioButton2.Name = "cxFlatRadioButton2";
            this.cxFlatRadioButton2.Size = new System.Drawing.Size(170, 20);
            this.cxFlatRadioButton2.TabIndex = 1;
            this.cxFlatRadioButton2.TabStop = true;
            this.cxFlatRadioButton2.Text = "cxFlatRadioButton2";
            this.cxFlatRadioButton2.UseVisualStyleBackColor = true;
            // 
            // cxFlatRadioButton1
            // 
            this.cxFlatRadioButton1.AutoSize = true;
            this.cxFlatRadioButton1.CheckedColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(158)))), ((int)(((byte)(255)))));
            this.cxFlatRadioButton1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatRadioButton1.Location = new System.Drawing.Point(36, 54);
            this.cxFlatRadioButton1.Name = "cxFlatRadioButton1";
            this.cxFlatRadioButton1.Size = new System.Drawing.Size(170, 20);
            this.cxFlatRadioButton1.TabIndex = 0;
            this.cxFlatRadioButton1.TabStop = true;
            this.cxFlatRadioButton1.Text = "cxFlatRadioButton1";
            this.cxFlatRadioButton1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.White;
            this.tabPage2.Controls.Add(this.cxFlatRoundProgressBar4);
            this.tabPage2.Controls.Add(this.cxFlatProgressBar12);
            this.tabPage2.Controls.Add(this.cxFlatProgressBar11);
            this.tabPage2.Controls.Add(this.cxFlatProgressBar10);
            this.tabPage2.Controls.Add(this.cxFlatProgressBar9);
            this.tabPage2.Controls.Add(this.cxFlatProgressBar8);
            this.tabPage2.Controls.Add(this.cxFlatProgressBar7);
            this.tabPage2.Controls.Add(this.cxFlatProgressBar6);
            this.tabPage2.Controls.Add(this.cxFlatProgressBar5);
            this.tabPage2.Controls.Add(this.cxFlatProgressBar4);
            this.tabPage2.Controls.Add(this.cxFlatProgressBar3);
            this.tabPage2.Controls.Add(this.cxFlatProgressBar2);
            this.tabPage2.Controls.Add(this.cxFlatRoundProgressBar3);
            this.tabPage2.Controls.Add(this.cxFlatRoundProgressBar2);
            this.tabPage2.Controls.Add(this.cxFlatSimpleButton6);
            this.tabPage2.Controls.Add(this.cxFlatSimpleButton5);
            this.tabPage2.Controls.Add(this.cxFlatSimpleButton4);
            this.tabPage2.Controls.Add(this.cxFlatSimpleButton3);
            this.tabPage2.Controls.Add(this.cxFlatSimpleButton2);
            this.tabPage2.Controls.Add(this.cxFlatSimpleButton1);
            this.tabPage2.Controls.Add(this.cxFlatRoundButton7);
            this.tabPage2.Controls.Add(this.cxFlatRoundButton6);
            this.tabPage2.Controls.Add(this.cxFlatRoundButton5);
            this.tabPage2.Controls.Add(this.cxFlatRoundButton4);
            this.tabPage2.Controls.Add(this.cxFlatRoundButton3);
            this.tabPage2.Controls.Add(this.cxFlatRoundButton2);
            this.tabPage2.Controls.Add(this.cxFlatButton9);
            this.tabPage2.Controls.Add(this.cxFlatButton8);
            this.tabPage2.Controls.Add(this.cxFlatButton7);
            this.tabPage2.Controls.Add(this.cxFlatButton6);
            this.tabPage2.Controls.Add(this.cxFlatButton5);
            this.tabPage2.Controls.Add(this.cxFlatButton4);
            this.tabPage2.Location = new System.Drawing.Point(0, 40);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(825, 452);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            // 
            // cxFlatRoundProgressBar4
            // 
            this.cxFlatRoundProgressBar4.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.cxFlatRoundProgressBar4.IsError = false;
            this.cxFlatRoundProgressBar4.Location = new System.Drawing.Point(393, 335);
            this.cxFlatRoundProgressBar4.Name = "cxFlatRoundProgressBar4";
            this.cxFlatRoundProgressBar4.Size = new System.Drawing.Size(108, 108);
            this.cxFlatRoundProgressBar4.TabIndex = 31;
            this.cxFlatRoundProgressBar4.Text = "cxFlatRoundProgressBar4";
            this.cxFlatRoundProgressBar4.ValueNumber = 50;
            // 
            // cxFlatProgressBar12
            // 
            this.cxFlatProgressBar12.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cxFlatProgressBar12.IsError = true;
            this.cxFlatProgressBar12.Location = new System.Drawing.Point(16, 305);
            this.cxFlatProgressBar12.Name = "cxFlatProgressBar12";
            this.cxFlatProgressBar12.ProgressBarStyle = CxFlatUI.CxFlatProgressBar.Style.ValueInSide;
            this.cxFlatProgressBar12.Size = new System.Drawing.Size(336, 14);
            this.cxFlatProgressBar12.TabIndex = 30;
            this.cxFlatProgressBar12.Text = "cxFlatProgressBar12";
            this.cxFlatProgressBar12.ValueNumber = 50;
            // 
            // cxFlatProgressBar11
            // 
            this.cxFlatProgressBar11.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cxFlatProgressBar11.IsError = false;
            this.cxFlatProgressBar11.Location = new System.Drawing.Point(16, 279);
            this.cxFlatProgressBar11.Name = "cxFlatProgressBar11";
            this.cxFlatProgressBar11.ProgressBarStyle = CxFlatUI.CxFlatProgressBar.Style.ValueInSide;
            this.cxFlatProgressBar11.Size = new System.Drawing.Size(336, 14);
            this.cxFlatProgressBar11.TabIndex = 29;
            this.cxFlatProgressBar11.Text = "cxFlatProgressBar11";
            this.cxFlatProgressBar11.ValueNumber = 100;
            // 
            // cxFlatProgressBar10
            // 
            this.cxFlatProgressBar10.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cxFlatProgressBar10.IsError = false;
            this.cxFlatProgressBar10.Location = new System.Drawing.Point(16, 253);
            this.cxFlatProgressBar10.Name = "cxFlatProgressBar10";
            this.cxFlatProgressBar10.ProgressBarStyle = CxFlatUI.CxFlatProgressBar.Style.ValueInSide;
            this.cxFlatProgressBar10.Size = new System.Drawing.Size(336, 14);
            this.cxFlatProgressBar10.TabIndex = 28;
            this.cxFlatProgressBar10.Text = "cxFlatProgressBar10";
            this.cxFlatProgressBar10.ValueNumber = 25;
            // 
            // cxFlatProgressBar9
            // 
            this.cxFlatProgressBar9.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cxFlatProgressBar9.IsError = true;
            this.cxFlatProgressBar9.Location = new System.Drawing.Point(393, 305);
            this.cxFlatProgressBar9.Name = "cxFlatProgressBar9";
            this.cxFlatProgressBar9.ProgressBarStyle = CxFlatUI.CxFlatProgressBar.Style.ValueOutSide;
            this.cxFlatProgressBar9.Size = new System.Drawing.Size(408, 14);
            this.cxFlatProgressBar9.TabIndex = 27;
            this.cxFlatProgressBar9.Text = "cxFlatProgressBar9";
            this.cxFlatProgressBar9.ValueNumber = 50;
            // 
            // cxFlatProgressBar8
            // 
            this.cxFlatProgressBar8.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cxFlatProgressBar8.IsError = false;
            this.cxFlatProgressBar8.Location = new System.Drawing.Point(393, 279);
            this.cxFlatProgressBar8.Name = "cxFlatProgressBar8";
            this.cxFlatProgressBar8.ProgressBarStyle = CxFlatUI.CxFlatProgressBar.Style.ValueOutSide;
            this.cxFlatProgressBar8.Size = new System.Drawing.Size(408, 14);
            this.cxFlatProgressBar8.TabIndex = 26;
            this.cxFlatProgressBar8.Text = "cxFlatProgressBar8";
            this.cxFlatProgressBar8.ValueNumber = 100;
            // 
            // cxFlatProgressBar7
            // 
            this.cxFlatProgressBar7.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cxFlatProgressBar7.IsError = false;
            this.cxFlatProgressBar7.Location = new System.Drawing.Point(393, 253);
            this.cxFlatProgressBar7.Name = "cxFlatProgressBar7";
            this.cxFlatProgressBar7.ProgressBarStyle = CxFlatUI.CxFlatProgressBar.Style.ValueOutSide;
            this.cxFlatProgressBar7.Size = new System.Drawing.Size(408, 14);
            this.cxFlatProgressBar7.TabIndex = 25;
            this.cxFlatProgressBar7.Text = "cxFlatProgressBar7";
            this.cxFlatProgressBar7.ValueNumber = 25;
            // 
            // cxFlatProgressBar6
            // 
            this.cxFlatProgressBar6.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cxFlatProgressBar6.IsError = true;
            this.cxFlatProgressBar6.Location = new System.Drawing.Point(4, 409);
            this.cxFlatProgressBar6.Name = "cxFlatProgressBar6";
            this.cxFlatProgressBar6.ProgressBarStyle = CxFlatUI.CxFlatProgressBar.Style.ToolTip;
            this.cxFlatProgressBar6.Size = new System.Drawing.Size(361, 32);
            this.cxFlatProgressBar6.TabIndex = 24;
            this.cxFlatProgressBar6.Text = "cxFlatProgressBar6";
            this.cxFlatProgressBar6.ValueNumber = 50;
            // 
            // cxFlatProgressBar5
            // 
            this.cxFlatProgressBar5.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cxFlatProgressBar5.IsError = false;
            this.cxFlatProgressBar5.Location = new System.Drawing.Point(4, 371);
            this.cxFlatProgressBar5.Name = "cxFlatProgressBar5";
            this.cxFlatProgressBar5.ProgressBarStyle = CxFlatUI.CxFlatProgressBar.Style.ToolTip;
            this.cxFlatProgressBar5.Size = new System.Drawing.Size(361, 32);
            this.cxFlatProgressBar5.TabIndex = 23;
            this.cxFlatProgressBar5.Text = "cxFlatProgressBar5";
            this.cxFlatProgressBar5.ValueNumber = 100;
            // 
            // cxFlatProgressBar4
            // 
            this.cxFlatProgressBar4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cxFlatProgressBar4.IsError = false;
            this.cxFlatProgressBar4.Location = new System.Drawing.Point(393, 227);
            this.cxFlatProgressBar4.Name = "cxFlatProgressBar4";
            this.cxFlatProgressBar4.ProgressBarStyle = CxFlatUI.CxFlatProgressBar.Style.ValueOutSide;
            this.cxFlatProgressBar4.Size = new System.Drawing.Size(408, 14);
            this.cxFlatProgressBar4.TabIndex = 22;
            this.cxFlatProgressBar4.Text = "cxFlatProgressBar4";
            this.cxFlatProgressBar4.ValueNumber = 0;
            // 
            // cxFlatProgressBar3
            // 
            this.cxFlatProgressBar3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cxFlatProgressBar3.IsError = false;
            this.cxFlatProgressBar3.Location = new System.Drawing.Point(16, 227);
            this.cxFlatProgressBar3.Name = "cxFlatProgressBar3";
            this.cxFlatProgressBar3.ProgressBarStyle = CxFlatUI.CxFlatProgressBar.Style.ValueInSide;
            this.cxFlatProgressBar3.Size = new System.Drawing.Size(336, 14);
            this.cxFlatProgressBar3.TabIndex = 21;
            this.cxFlatProgressBar3.Text = "cxFlatProgressBar3";
            this.cxFlatProgressBar3.ValueNumber = 0;
            // 
            // cxFlatProgressBar2
            // 
            this.cxFlatProgressBar2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cxFlatProgressBar2.IsError = false;
            this.cxFlatProgressBar2.Location = new System.Drawing.Point(4, 333);
            this.cxFlatProgressBar2.Name = "cxFlatProgressBar2";
            this.cxFlatProgressBar2.ProgressBarStyle = CxFlatUI.CxFlatProgressBar.Style.ToolTip;
            this.cxFlatProgressBar2.Size = new System.Drawing.Size(361, 32);
            this.cxFlatProgressBar2.TabIndex = 20;
            this.cxFlatProgressBar2.Text = "cxFlatProgressBar2";
            this.cxFlatProgressBar2.ValueNumber = 25;
            // 
            // cxFlatRoundProgressBar3
            // 
            this.cxFlatRoundProgressBar3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.cxFlatRoundProgressBar3.IsError = true;
            this.cxFlatRoundProgressBar3.Location = new System.Drawing.Point(681, 335);
            this.cxFlatRoundProgressBar3.Name = "cxFlatRoundProgressBar3";
            this.cxFlatRoundProgressBar3.Size = new System.Drawing.Size(108, 108);
            this.cxFlatRoundProgressBar3.TabIndex = 19;
            this.cxFlatRoundProgressBar3.Text = "cxFlatRoundProgressBar3";
            this.cxFlatRoundProgressBar3.ValueNumber = 50;
            // 
            // cxFlatRoundProgressBar2
            // 
            this.cxFlatRoundProgressBar2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.cxFlatRoundProgressBar2.IsError = false;
            this.cxFlatRoundProgressBar2.Location = new System.Drawing.Point(537, 335);
            this.cxFlatRoundProgressBar2.Name = "cxFlatRoundProgressBar2";
            this.cxFlatRoundProgressBar2.Size = new System.Drawing.Size(108, 108);
            this.cxFlatRoundProgressBar2.TabIndex = 18;
            this.cxFlatRoundProgressBar2.Text = "cxFlatRoundProgressBar2";
            this.cxFlatRoundProgressBar2.ValueNumber = 100;
            // 
            // cxFlatSimpleButton6
            // 
            this.cxFlatSimpleButton6.ButtonType = CxFlatUI.ButtonType.Danger;
            this.cxFlatSimpleButton6.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatSimpleButton6.Location = new System.Drawing.Point(687, 93);
            this.cxFlatSimpleButton6.Name = "cxFlatSimpleButton6";
            this.cxFlatSimpleButton6.Size = new System.Drawing.Size(123, 41);
            this.cxFlatSimpleButton6.TabIndex = 17;
            this.cxFlatSimpleButton6.Text = "危险按钮";
            this.cxFlatSimpleButton6.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatSimpleButton5
            // 
            this.cxFlatSimpleButton5.ButtonType = CxFlatUI.ButtonType.Waring;
            this.cxFlatSimpleButton5.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatSimpleButton5.Location = new System.Drawing.Point(552, 93);
            this.cxFlatSimpleButton5.Name = "cxFlatSimpleButton5";
            this.cxFlatSimpleButton5.Size = new System.Drawing.Size(123, 41);
            this.cxFlatSimpleButton5.TabIndex = 16;
            this.cxFlatSimpleButton5.Text = "警告按钮";
            this.cxFlatSimpleButton5.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatSimpleButton4
            // 
            this.cxFlatSimpleButton4.ButtonType = CxFlatUI.ButtonType.Info;
            this.cxFlatSimpleButton4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatSimpleButton4.Location = new System.Drawing.Point(417, 93);
            this.cxFlatSimpleButton4.Name = "cxFlatSimpleButton4";
            this.cxFlatSimpleButton4.Size = new System.Drawing.Size(123, 41);
            this.cxFlatSimpleButton4.TabIndex = 15;
            this.cxFlatSimpleButton4.Text = "信息按钮";
            this.cxFlatSimpleButton4.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatSimpleButton3
            // 
            this.cxFlatSimpleButton3.ButtonType = CxFlatUI.ButtonType.Success;
            this.cxFlatSimpleButton3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatSimpleButton3.Location = new System.Drawing.Point(282, 93);
            this.cxFlatSimpleButton3.Name = "cxFlatSimpleButton3";
            this.cxFlatSimpleButton3.Size = new System.Drawing.Size(123, 41);
            this.cxFlatSimpleButton3.TabIndex = 14;
            this.cxFlatSimpleButton3.Text = "成功按钮";
            this.cxFlatSimpleButton3.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatSimpleButton2
            // 
            this.cxFlatSimpleButton2.ButtonType = CxFlatUI.ButtonType.Primary;
            this.cxFlatSimpleButton2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatSimpleButton2.Location = new System.Drawing.Point(147, 93);
            this.cxFlatSimpleButton2.Name = "cxFlatSimpleButton2";
            this.cxFlatSimpleButton2.Size = new System.Drawing.Size(123, 41);
            this.cxFlatSimpleButton2.TabIndex = 13;
            this.cxFlatSimpleButton2.Text = "主要按钮";
            this.cxFlatSimpleButton2.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatSimpleButton1
            // 
            this.cxFlatSimpleButton1.ButtonType = CxFlatUI.ButtonType.Default;
            this.cxFlatSimpleButton1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatSimpleButton1.Location = new System.Drawing.Point(12, 93);
            this.cxFlatSimpleButton1.Name = "cxFlatSimpleButton1";
            this.cxFlatSimpleButton1.Size = new System.Drawing.Size(123, 41);
            this.cxFlatSimpleButton1.TabIndex = 12;
            this.cxFlatSimpleButton1.Text = "朴素按钮";
            this.cxFlatSimpleButton1.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatRoundButton7
            // 
            this.cxFlatRoundButton7.BackColor = System.Drawing.Color.Transparent;
            this.cxFlatRoundButton7.ButtonType = CxFlatUI.ButtonType.Danger;
            this.cxFlatRoundButton7.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatRoundButton7.Location = new System.Drawing.Point(687, 161);
            this.cxFlatRoundButton7.Name = "cxFlatRoundButton7";
            this.cxFlatRoundButton7.Size = new System.Drawing.Size(123, 40);
            this.cxFlatRoundButton7.TabIndex = 11;
            this.cxFlatRoundButton7.Text = "危险按钮";
            this.cxFlatRoundButton7.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatRoundButton6
            // 
            this.cxFlatRoundButton6.BackColor = System.Drawing.Color.Transparent;
            this.cxFlatRoundButton6.ButtonType = CxFlatUI.ButtonType.Waring;
            this.cxFlatRoundButton6.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatRoundButton6.Location = new System.Drawing.Point(552, 161);
            this.cxFlatRoundButton6.Name = "cxFlatRoundButton6";
            this.cxFlatRoundButton6.Size = new System.Drawing.Size(123, 40);
            this.cxFlatRoundButton6.TabIndex = 10;
            this.cxFlatRoundButton6.Text = "警告按钮";
            this.cxFlatRoundButton6.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatRoundButton5
            // 
            this.cxFlatRoundButton5.BackColor = System.Drawing.Color.Transparent;
            this.cxFlatRoundButton5.ButtonType = CxFlatUI.ButtonType.Info;
            this.cxFlatRoundButton5.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatRoundButton5.Location = new System.Drawing.Point(417, 161);
            this.cxFlatRoundButton5.Name = "cxFlatRoundButton5";
            this.cxFlatRoundButton5.Size = new System.Drawing.Size(123, 40);
            this.cxFlatRoundButton5.TabIndex = 9;
            this.cxFlatRoundButton5.Text = "信息按钮";
            this.cxFlatRoundButton5.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatRoundButton4
            // 
            this.cxFlatRoundButton4.BackColor = System.Drawing.Color.Transparent;
            this.cxFlatRoundButton4.ButtonType = CxFlatUI.ButtonType.Success;
            this.cxFlatRoundButton4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatRoundButton4.Location = new System.Drawing.Point(282, 161);
            this.cxFlatRoundButton4.Name = "cxFlatRoundButton4";
            this.cxFlatRoundButton4.Size = new System.Drawing.Size(123, 40);
            this.cxFlatRoundButton4.TabIndex = 8;
            this.cxFlatRoundButton4.Text = "成功按钮";
            this.cxFlatRoundButton4.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatRoundButton3
            // 
            this.cxFlatRoundButton3.BackColor = System.Drawing.Color.Transparent;
            this.cxFlatRoundButton3.ButtonType = CxFlatUI.ButtonType.Primary;
            this.cxFlatRoundButton3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatRoundButton3.Location = new System.Drawing.Point(147, 161);
            this.cxFlatRoundButton3.Name = "cxFlatRoundButton3";
            this.cxFlatRoundButton3.Size = new System.Drawing.Size(123, 40);
            this.cxFlatRoundButton3.TabIndex = 7;
            this.cxFlatRoundButton3.Text = "主要按钮";
            this.cxFlatRoundButton3.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatRoundButton2
            // 
            this.cxFlatRoundButton2.BackColor = System.Drawing.Color.Transparent;
            this.cxFlatRoundButton2.ButtonType = CxFlatUI.ButtonType.Default;
            this.cxFlatRoundButton2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatRoundButton2.Location = new System.Drawing.Point(12, 161);
            this.cxFlatRoundButton2.Name = "cxFlatRoundButton2";
            this.cxFlatRoundButton2.Size = new System.Drawing.Size(123, 40);
            this.cxFlatRoundButton2.TabIndex = 6;
            this.cxFlatRoundButton2.Text = "圆角按钮";
            this.cxFlatRoundButton2.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatButton9
            // 
            this.cxFlatButton9.ButtonType = CxFlatUI.ButtonType.Default;
            this.cxFlatButton9.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatButton9.Location = new System.Drawing.Point(12, 18);
            this.cxFlatButton9.Name = "cxFlatButton9";
            this.cxFlatButton9.Size = new System.Drawing.Size(123, 42);
            this.cxFlatButton9.TabIndex = 5;
            this.cxFlatButton9.Text = "默认按钮";
            this.cxFlatButton9.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatButton8
            // 
            this.cxFlatButton8.ButtonType = CxFlatUI.ButtonType.Danger;
            this.cxFlatButton8.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatButton8.Location = new System.Drawing.Point(687, 18);
            this.cxFlatButton8.Name = "cxFlatButton8";
            this.cxFlatButton8.Size = new System.Drawing.Size(123, 42);
            this.cxFlatButton8.TabIndex = 4;
            this.cxFlatButton8.Text = "危险按钮";
            this.cxFlatButton8.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatButton7
            // 
            this.cxFlatButton7.ButtonType = CxFlatUI.ButtonType.Waring;
            this.cxFlatButton7.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatButton7.Location = new System.Drawing.Point(552, 18);
            this.cxFlatButton7.Name = "cxFlatButton7";
            this.cxFlatButton7.Size = new System.Drawing.Size(123, 42);
            this.cxFlatButton7.TabIndex = 3;
            this.cxFlatButton7.Text = "警告按钮";
            this.cxFlatButton7.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatButton6
            // 
            this.cxFlatButton6.ButtonType = CxFlatUI.ButtonType.Info;
            this.cxFlatButton6.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatButton6.Location = new System.Drawing.Point(417, 18);
            this.cxFlatButton6.Name = "cxFlatButton6";
            this.cxFlatButton6.Size = new System.Drawing.Size(123, 42);
            this.cxFlatButton6.TabIndex = 2;
            this.cxFlatButton6.Text = "信息按钮";
            this.cxFlatButton6.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatButton5
            // 
            this.cxFlatButton5.ButtonType = CxFlatUI.ButtonType.Success;
            this.cxFlatButton5.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatButton5.Location = new System.Drawing.Point(282, 18);
            this.cxFlatButton5.Name = "cxFlatButton5";
            this.cxFlatButton5.Size = new System.Drawing.Size(123, 42);
            this.cxFlatButton5.TabIndex = 1;
            this.cxFlatButton5.Text = "成功按钮";
            this.cxFlatButton5.TextColor = System.Drawing.Color.White;
            // 
            // cxFlatButton4
            // 
            this.cxFlatButton4.ButtonType = CxFlatUI.ButtonType.Primary;
            this.cxFlatButton4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatButton4.Location = new System.Drawing.Point(147, 18);
            this.cxFlatButton4.Name = "cxFlatButton4";
            this.cxFlatButton4.Size = new System.Drawing.Size(123, 42);
            this.cxFlatButton4.TabIndex = 0;
            this.cxFlatButton4.Text = "主要按钮";
            this.cxFlatButton4.TextColor = System.Drawing.Color.White;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.White;
            this.tabPage3.Controls.Add(this.comboBox1);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Controls.Add(this.cxFlatDatePicker1);
            this.tabPage3.Location = new System.Drawing.Point(0, 40);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(825, 452);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(391, 119);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 29);
            this.comboBox1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // cxFlatDatePicker1
            // 
            this.cxFlatDatePicker1.Date = new System.DateTime(2018, 8, 29, 21, 55, 38, 261);
            this.cxFlatDatePicker1.Location = new System.Drawing.Point(56, 64);
            this.cxFlatDatePicker1.Name = "cxFlatDatePicker1";
            this.cxFlatDatePicker1.Size = new System.Drawing.Size(250, 270);
            this.cxFlatDatePicker1.TabIndex = 0;
            this.cxFlatDatePicker1.Text = "cxFlatDatePicker1";
            this.cxFlatDatePicker1.onDateChanged += new CxFlatUI.Controls.CxFlatDatePicker.DateChanged(this.cxFlatDatePicker1_onDateChanged);
            // 
            // cxFlatButton1
            // 
            this.cxFlatButton1.ButtonType = CxFlatUI.ButtonType.Primary;
            this.cxFlatButton1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cxFlatButton1.Location = new System.Drawing.Point(5, 6);
            this.cxFlatButton1.Name = "cxFlatButton1";
            this.cxFlatButton1.Size = new System.Drawing.Size(128, 39);
            this.cxFlatButton1.TabIndex = 9;
            this.cxFlatButton1.Text = "cxFlatButton1";
            this.cxFlatButton1.TextColor = System.Drawing.Color.White;
            this.cxFlatButton1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cxFlatComboBox1
            // 
            this.cxFlatComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cxFlatComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cxFlatComboBox1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.cxFlatComboBox1.FormattingEnabled = true;
            this.cxFlatComboBox1.ItemHeight = 30;
            this.cxFlatComboBox1.Location = new System.Drawing.Point(322, 379);
            this.cxFlatComboBox1.Name = "cxFlatComboBox1";
            this.cxFlatComboBox1.Size = new System.Drawing.Size(222, 36);
            this.cxFlatComboBox1.TabIndex = 29;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(825, 546);
            this.Controls.Add(this.cxFlatStatusBar1);
            this.Controls.Add(this.cxFlatTabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(1920, 1050);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.cxFlatTabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.cxFlatContextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cxFlatPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cxFlatPictureBox2)).EndInit();
            this.cxFlatGroupBox2.ResumeLayout(false);
            this.cxFlatGroupBox2.PerformLayout();
            this.cxFlatGroupBox1.ResumeLayout(false);
            this.cxFlatGroupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private CxFlatCheckBox cxFlatCheckBox1;
        private System.Windows.Forms.Timer timer1;
        private CxFlatGroupBox cxFlatGroupBox1;
        private CxFlatButton cxFlatButton1;
        private CxFlatToggle cxFlatToggle1;
        private CxFlatToggle cxFlatToggle2;
        private CxFlatTabControl cxFlatTabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private CxFlatAlertBox cxFlatAlertBox1;
        private CxFlatAlertBox cxFlatAlertBox4;
        private CxFlatAlertBox cxFlatAlertBox3;
        private CxFlatAlertBox cxFlatAlertBox2;
        private CxFlatSwitch cxFlatSwitch1;
        private CxFlatGroupBox cxFlatGroupBox2;
        private CxFlatSwitch cxFlatSwitch2;
        private CxFlatCheckBox cxFlatCheckBox2;
        private CxFlatPictureBox cxFlatPictureBox1;
        private CxFlatPictureBox cxFlatPictureBox2;
        private CxFlatSliderBar cxFlatSliderBar1;
        private CxFlatRadioButton cxFlatRadioButton3;
        private CxFlatRadioButton cxFlatRadioButton2;
        private CxFlatRadioButton cxFlatRadioButton1;
        private CxFlatButton cxFlatButton8;
        private CxFlatButton cxFlatButton7;
        private CxFlatButton cxFlatButton6;
        private CxFlatButton cxFlatButton5;
        private CxFlatButton cxFlatButton4;
        private CxFlatButton cxFlatButton9;
        private CxFlatRoundButton cxFlatRoundButton7;
        private CxFlatRoundButton cxFlatRoundButton6;
        private CxFlatRoundButton cxFlatRoundButton5;
        private CxFlatRoundButton cxFlatRoundButton4;
        private CxFlatRoundButton cxFlatRoundButton3;
        private CxFlatRoundButton cxFlatRoundButton2;
        private CxFlatSimpleButton cxFlatSimpleButton1;
        private CxFlatSimpleButton cxFlatSimpleButton2;
        private CxFlatSimpleButton cxFlatSimpleButton6;
        private CxFlatSimpleButton cxFlatSimpleButton5;
        private CxFlatSimpleButton cxFlatSimpleButton4;
        private CxFlatSimpleButton cxFlatSimpleButton3;
        private CxFlatNumericUpDown cxFlatNumericUpDown1;
        private CxFlatNumericUpDown cxFlatNumericUpDown2;
        private CxFlatRoundProgressBar cxFlatRoundProgressBar2;
        private CxFlatRoundProgressBar cxFlatRoundProgressBar3;
        private CxFlatProgressBar cxFlatProgressBar2;
        private CxFlatProgressBar cxFlatProgressBar4;
        private CxFlatProgressBar cxFlatProgressBar3;
        private CxFlatProgressBar cxFlatProgressBar6;
        private CxFlatProgressBar cxFlatProgressBar5;
        private CxFlatProgressBar cxFlatProgressBar8;
        private CxFlatProgressBar cxFlatProgressBar7;
        private CxFlatProgressBar cxFlatProgressBar12;
        private CxFlatProgressBar cxFlatProgressBar11;
        private CxFlatProgressBar cxFlatProgressBar10;
        private CxFlatProgressBar cxFlatProgressBar9;
        private CxFlatRoundProgressBar cxFlatRoundProgressBar4;
        private CxFlatStatusBar cxFlatStatusBar1;
        private CxFlatTextBox cxFlatTextBox1;
        private CxFlatContextMenuStrip cxFlatContextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem abcdefToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sdssToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sdhlkjdToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem sadsdbToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 下拉菜单ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem asdfgToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private CxFlatButton cxFlatButton2;
        private System.Windows.Forms.TabPage tabPage3;
        private CxFlatDatePicker cxFlatDatePicker1;
        private System.Windows.Forms.Label label1;
        private CxFlatTextBox cxFlatTextBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private CxFlatComboBox cxFlatComboBox1;
    }
}

