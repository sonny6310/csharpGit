﻿namespace CxFlatUI
{
    public enum ButtonType
    {
        Default=0,
        Primary=1,
        Success=2,
        Info=3,
        Waring=4,
        Danger=5
    }
}