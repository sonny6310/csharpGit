# CxFlatUI
![image](https://github.com/HuJinguang/CxFlatUI/blob/master/CxFlatDemo/screenshot/6.png)
![image](https://github.com/HuJinguang/CxFlatUI/blob/master/CxFlatDemo/screenshot/5.png)
![image](https://github.com/HuJinguang/CxFlatUI/blob/master/CxFlatDemo/screenshot/7.png)
## 当前控件
+ AlertBox
+ Button
+ CheckBox
+ DatePicker
+ GroupBox
+ NumericUpDown
+ PictureBox
+ ProgressBar
+ RadioButton
+ RoundButton
+ RoundProgressBar
+ SimpleButton
+ SliderBar
+ StatusBar
+ Switch
+ TabControl
+ Toggle

持续更新
